#import <UIKit/UIKit.h>

#import "SimpleVideoFileFilterAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SimpleVideoFileFilterAppDelegate class]));
    }
}
