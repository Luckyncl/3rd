//
//  ShowView.h
//  SimpleVideoFileFilter
//
//  Created by Apple on 2018/3/13.
//  Copyright © 2018年 Cell Phone. All rights reserved.
//

#import "GPUImageView.h"

@interface ShowView : GPUImageView

@end
