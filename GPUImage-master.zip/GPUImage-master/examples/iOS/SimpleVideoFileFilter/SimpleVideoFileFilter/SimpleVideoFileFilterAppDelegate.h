#import <UIKit/UIKit.h>
@class SimpleVideoFileFilterViewController;

@interface SimpleVideoFileFilterAppDelegate : UIResponder <UIApplicationDelegate>
{
    SimpleVideoFileFilterViewController *rootViewController;
}

@property (strong, nonatomic) UIWindow *window;

@end
