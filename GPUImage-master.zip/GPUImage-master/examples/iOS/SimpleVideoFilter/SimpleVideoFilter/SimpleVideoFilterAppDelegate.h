#import <UIKit/UIKit.h>
@class SimpleVideoFilterViewController;

@interface SimpleVideoFilterAppDelegate : UIResponder <UIApplicationDelegate>
{
    SimpleVideoFilterViewController *rootViewController;
}

@property (strong, nonatomic) UIWindow *window;

@end
