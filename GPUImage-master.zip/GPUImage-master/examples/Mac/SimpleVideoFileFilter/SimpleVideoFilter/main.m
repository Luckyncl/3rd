//
//  main.m
//  SimpleVideoFilter
//
//  Created by Janie Clayton-Hasz on 1/8/15.
//  Copyright (c) 2015 Red Queen Coder, LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
