#import <Cocoa/Cocoa.h>
#import "SLSSimpleVideoFileFilterWindowController.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    SLSSimpleVideoFileFilterWindowController *simpleVideoFileFilterWindowController;
}

@end

