import Cocoa

NSApplicationMain(Process.argc, Process.unsafeArgv)