#import "GPUImageSobelEdgeDetectionFilter.h"

@interface GPUImagePrewittEdgeDetectionFilter : GPUImageSobelEdgeDetectionFilter

@end
