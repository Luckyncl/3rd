#import "GPUImageTwoInputFilter.h"

@interface GPUImageHardLightBlendFilter : GPUImageTwoInputFilter
{
}

@end
