#import "GPUImageTwoInputFilter.h"

@interface GPUImageExclusionBlendFilter : GPUImageTwoInputFilter
{
}

@end
